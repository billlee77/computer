vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:38 -0000
vti_timecreated:TR|13 Oct 2003 17:51:13 -0000
vti_lineageid:SR|{13D60504-8754-494B-881A-49E776791125}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|11 Oct 2003 05:25:58 -0000
vti_filesize:IR|4943
