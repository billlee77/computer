vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:36 -0000
vti_timecreated:TR|13 Oct 2003 17:51:13 -0000
vti_lineageid:SR|{D3657826-4EC9-4084-A4A7-6C298E599B6F}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|12 Oct 2003 22:00:20 -0000
vti_filesize:IR|31540
