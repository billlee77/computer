vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:36 -0000
vti_timecreated:TR|13 Oct 2003 17:51:15 -0000
vti_lineageid:SR|{4E7D86A3-915C-46C2-AB0C-145145270C77}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|13 Oct 2003 00:12:14 -0000
vti_filesize:IR|3928
