vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:36 -0000
vti_timecreated:TR|13 Oct 2003 17:51:14 -0000
vti_lineageid:SR|{51E4F47B-B8B5-4A73-8365-229678F8A9E2}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|11 Oct 2003 04:51:46 -0000
vti_filesize:IR|3697
