vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:39 -0000
vti_timecreated:TR|13 Oct 2003 17:51:14 -0000
vti_lineageid:SR|{2F8A45B7-AC0E-4D55-8BA0-D5A92BF3A5CB}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|11 Oct 2003 04:51:46 -0000
vti_filesize:IR|13829
