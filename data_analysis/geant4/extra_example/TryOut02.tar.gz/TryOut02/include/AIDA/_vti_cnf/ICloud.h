vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:37 -0000
vti_timecreated:TR|13 Oct 2003 17:51:14 -0000
vti_lineageid:SR|{EF5E72A3-C9EE-4F33-8B05-F1E45639E5B5}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|11 Oct 2003 04:51:46 -0000
vti_filesize:IR|3548
