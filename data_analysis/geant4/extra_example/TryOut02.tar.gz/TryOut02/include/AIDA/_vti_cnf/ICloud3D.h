vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2003 04:13:01 -0000
vti_extenderversion:SR|5.0.2.2623
vti_author:SR|SLDXPLAP2\\tonyj
vti_modifiedby:SR|SLDXPLAP2\\tonyj
vti_nexttolasttimemodified:TR|14 Oct 2003 04:03:38 -0000
vti_timecreated:TR|13 Oct 2003 17:51:13 -0000
vti_lineageid:SR|{10015619-A63E-4D78-B13C-84D83F6AB30E}
vti_backlinkinfo:VX|
vti_cacheddtm:TX|11 Oct 2003 04:51:46 -0000
vti_filesize:IR|9476
