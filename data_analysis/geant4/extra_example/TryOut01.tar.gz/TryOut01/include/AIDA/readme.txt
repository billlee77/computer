These are a copy of the official AIDA header files taken from:

CVSROOT     :pserver:anoncvs@cvs.freehep.org:/cvs/aida
MODULE      aida
DIRECTORY   cpp/AIDA
Version     : 3.0

added ITupleEntry dummy class.

