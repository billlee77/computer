#
# Setup for Unix (Linux, Solaris, MacOS X)
#

export G4ANALYSIS_USE=1
