/*
 * Written by Solar Designer <solar at openwall.com> and placed in the
 * public domain.
 */

#ifndef WORDSET_4K_H__
#define WORDSET_4K_H__

extern char _passwdqc_wordset_4k[0x1000][6];

#endif /* WORDSET_4K_H__ */
